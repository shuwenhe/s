This package provides a minimal Go-like parser implemented in S.

Current goals:
- Parse `package` declarations
- Parse `import` declarations (single and grouped, alias and dot imports)
- Collect top-level item token segments as raw text for later parsing

This is an incremental scaffold — later commits will expand to full AST nodes
for `const/var/type/func`, types, statements, expressions, and generics.
