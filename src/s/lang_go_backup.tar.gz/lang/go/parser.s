package s

use std.vec.Vec
use std.option.Option
use std.result.Result
use std.prelude.join_strings

// Minimal Go parser scaffold implemented in S.

struct GoImport {
    String alias,
    String path,
}

struct GoSource {
    String package_name,
    Vec[GoImport] imports,
    Vec[String] items, // raw token-joined items for now
}

struct GoParseError {
    String message,
    i32 line,
    i32 column,
}

struct GoParser {
    Vec[Token] tokens,
    i32 index,
}

func parse_go_source(String source) -> Result[GoSource, GoParseError] {
    match new_lexer(source).tokenize() {
        Result::Ok(tokens) => parse_go_tokens(tokens),
        Result::Err(err) => Result::Err(GoParseError {
            message: err.message,
            line: err.line,
            column: err.column,
        }),
    }
}

func parse_go_tokens(Vec[Token] tokens) -> Result[GoSource, GoParseError] {
    var p = GoParser { tokens: tokens, index: 0 }
    p.parse_source_file()
}

impl GoParser {
    func parse_source_file(mut self) -> Result[GoSource, GoParseError] {
        var package_name = Option::None
        if self.at_keyword("package") {
            self.advance()?
            var tok = self.peek()?
            if tok.kind == TokenKind::Ident {
                package_name = Option::Some(tok.value)
                self.advance()?
            } else {
                return Result::Err(self.error_here("expected package name"))
            }
        } else {
            return Result::Err(self.error_here("expected 'package' declaration"))
        }

        var imports = Vec[GoImport]()
        // allow multiple import blocks/lines
        while self.at_keyword("import") {
            self.advance()?
            if self.at_symbol("(") {
                self.advance()?
                while !self.eat_symbol(")") {
                    var imp = self.parse_import_spec()?
                    imports.push(imp)
                }
            } else {
                var imp = self.parse_import_spec()?
                imports.push(imp)
            }
        }

        // Collect remaining top-level items as raw segments for now.
        var items = Vec[String]()
        while !self.at(TokenKind::Eof) {
            var seg = self.collect_top_level_segment()?
            items.push(seg)
        }

        Result::Ok(GoSource {
            package_name: package_name.unwrap(),
            imports: imports,
            items: items,
        })
    }

    func parse_import_spec(mut self) -> Result[GoImport, GoParseError] {
        // import spec forms:
        //  "path"
        //  alias "path"
        //  . "path"
        var alias = ""
        var path = ""

        var next = self.peek()?
        if next.kind == TokenKind::String {
            // plain import
            path = next.value
            self.advance()?
            Result::Ok(GoImport { alias: alias, path: path })
        } else if next.kind == TokenKind::Ident && (self.peek_at(1).unwrap().kind == TokenKind::String) {
            alias = next.value
            self.advance()?
            path = self.expect_string()? 
            Result::Ok(GoImport { alias: alias, path: path })
        } else if next.kind == TokenKind::Symbol && next.value == "." {
            alias = "."
            self.advance()?
            path = self.expect_string()?
            Result::Ok(GoImport { alias: alias, path: path })
        } else {
            Result::Err(self.error_here("invalid import spec"))
        }
    }

    func collect_top_level_segment(mut self) -> Result[String, GoParseError] {
        // collect tokens until next top-level keyword (package/import) or EOF
        var parts = Vec[String]()
        while !self.at(TokenKind::Eof) {
            if self.at_keyword("package") || self.at_keyword("import") {
                break
            }
            var tok = self.advance()?
            parts.push(tok.value)
        }
        Result::Ok(join_strings(parts, " "))
    }

    // --- token helpers (small subset copied for isolation) ---
    func peek(self) -> Result[Token, GoParseError] {
        self.peek_at(0)
    }

    func peek_at(self, i32 offset) -> Result[Token, GoParseError] {
        if self.index >= len(self.tokens) {
            return Result::Err(GoParseError { message: "unexpected eof", line: 0, column: 0 })
        }
        var target = self.index + offset
        if target >= len(self.tokens) {
            target = len(self.tokens) - 1
        }
        Result::Ok(self.tokens[target])
    }

    func advance(mut self) -> Result[Token, GoParseError] {
        var token = self.peek()?
        self.index = self.index + 1
        Result::Ok(token)
    }

    func at(self, TokenKind kind) -> bool {
        self.peek().unwrap().kind == kind
    }

    func at_keyword(self, String value) -> bool {
        var token = self.peek().unwrap()
        (token.kind == TokenKind::Keyword && token.value == value) || (token.kind == TokenKind::Ident && token.value == value)
    }

    func at_symbol(self, String value) -> bool {
        var token = self.peek().unwrap()
        token.kind == TokenKind::Symbol && token.value == value
    }

    func eat_symbol(mut self, String value) -> bool {
        if self.at_symbol(value) {
            self.advance().unwrap()
            return true
        }
        false
    }

    func expect_string(mut self) -> Result[String, GoParseError] {
        var token = self.peek()?
        if token.kind == TokenKind::String {
            self.advance()?
            return Result::Ok(token.value)
        }
        Result::Err(self.error_here("expected string literal"))
    }

    func error_here(self, String message) -> GoParseError {
        var token = self.peek().unwrap()
        GoParseError { message: message, line: token.line, column: token.column }
    }
}
